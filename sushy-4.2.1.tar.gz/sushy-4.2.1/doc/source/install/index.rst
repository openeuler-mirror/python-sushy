================
Installing Sushy
================

At the command line::

    $ pip install sushy

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv sushy
    $ pip install sushy
